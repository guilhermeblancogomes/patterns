package Ex9_1;

public class Produtos{
	private String nomeProduto;
	private double precoProduto;
	public Produtos() {
			
	}
	public String getNomeProduto() {
		return nomeProduto;
	}
	public void setNomeProduto(String nomeProduto) {
		this.nomeProduto = nomeProduto;
	}
	public double getPrecoProduto() {
		return precoProduto;
	}
	public void setPrecoProduto(double precoProduto) {
		this.precoProduto = precoProduto;
	}
	
	
}


	// Guilherme Blanco Gomes
	// 201403856
