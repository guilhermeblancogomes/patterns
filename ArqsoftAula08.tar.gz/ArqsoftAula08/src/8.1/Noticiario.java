package Ex8_1;

public abstract class Noticiario {
	
	public abstract void notificaNoticia(String textoNoticia, int dia,   int mes, String topico); 

}



	// Guilherme Blanco Gomes
	// 201403856

