package Ex8_1;

public interface ConsomeNoticia {     
	public void notificaNoticia(String textoNoticia, int dia,     int mes, String topico); } 

	// Guilherme Blanco Gomes
	// 201403856

